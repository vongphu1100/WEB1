(function () {
  const P = {
    pkg: 'M16.5 9.4l-9-5.19M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16zM3.27 6.96L12 12.01l8.73-5.05M12 22.08V12',
    usr: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
    cart: 'M9 22a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM20 22a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6',
    search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.35-4.35',
    bolt: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z',
    down: 'M6 9l6 6 6-6',
    right: 'M9 18l6-6-6-6',
    book: 'M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z',
    filter: 'M22 3H2l8 9.46V19l4 2v-8.54L22 3z',
    ok: 'M22 11.08V12a10 10 0 1 1-5.93-9.14M22 4L12 14.01l-3-3'
  };
  const ic = (k, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${P[k]}"/></svg>`;
  const $ = (s, r = document) => r.querySelector(s);

  // Thông báo góc phải
  const box = document.createElement('div');
  box.id = 'toasts';
  document.body.appendChild(box);
  const toast = m => {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = ic('ok', 20) + '<span>' + m + '</span>';
    box.appendChild(t);
    setTimeout(() => t.remove(), 3200);
  };

  // Pop up
  const modal = (title, body, foot) => {
    const o = document.createElement('div');
    o.className = 'overlay';
    o.innerHTML = `<div class="modal"><button class="x" data-close>&times;</button><h3>${title}</h3>${body}${foot ? `<div class="mfoot">${foot}</div>` : ''}</div>`;
    o.onclick = e => { if (e.target === o || e.target.closest('[data-close]')) o.remove(); };
    document.body.appendChild(o);
    return o;
  };

  const table = (cols, rows, w = 860) =>
    `<div class="tbl-wrap"><table style="min-width:${w}px"><thead><tr>${cols.map(c => `<th style="width:${c[1]}">${c[0]}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;

  const badge = (c, t) => `<span class="badge ${c}">${t}</span>`;

  const go = (url, msg) => {
    try { sessionStorage.setItem('flash', msg); } catch (e) {}
    location.href = url;
  };

  window.UI = { $, ic, toast, modal, table, badge, go };

  try {
    const f = sessionStorage.getItem('flash');
    if (f) { sessionStorage.removeItem('flash'); toast(f); }
  } catch (e) {}

  const fill = () => document.querySelectorAll('[data-ic]').forEach(e => { e.innerHTML = ic(e.dataset.ic, +e.dataset.s || 20); });

  const page = document.body.dataset.page;
  if (!page) { fill(); return; } // trang đăng nhập: không có sidebar/header

  // Sidebar (dùng chung cho mọi trang)
  const nav = [['products', 'pkg', 'Sản phẩm'], ['customers', 'usr', 'Khách hàng'], ['orders', 'cart', 'Đơn hàng']];
  document.body.insertAdjacentHTML('afterbegin',
    `<aside class="sidebar">
      <a class="brand" href="index.html"><i class="logo">${ic('book', 20)}</i><div class="name"><b>Manga<span>House</span></b><small>Comic &amp; Manga Store</small></div></a>
      <nav class="nav">${nav.map(n => `<a href="${n[0]}.html" class="${n[0] === page ? 'act' : ''}">${ic(n[1])}<span>${n[2]}</span><em class="ico chev">${ic('right', 16)}</em></a>`).join('')}</nav>
      <div class="dd side-user">
        <div class="menu"><button data-a="info">Thông tin admin</button><button data-a="out">Đăng xuất</button></div>
        <button class="me" data-dd><i class="av">A</i><div class="meta"><b>Nguyễn Văn A</b><small>Quản trị viên</small></div><em class="ico">${ic('down', 16)}</em></button>
      </div>
    </aside>`);

  // Header (dùng chung cho mọi trang)
  $('.main').insertAdjacentHTML('afterbegin',
    `<header class="topbar"><h1>Xin chào Admin 👋</h1></header>`);

  fill();

  document.addEventListener('click', e => {
    const d = e.target.closest('[data-dd]');
    document.querySelectorAll('.dd.open').forEach(x => { if (!d || x !== d.parentElement) x.classList.remove('open'); });
    if (d) d.parentElement.classList.toggle('open');
    const a = e.target.closest('[data-a]');
    if (a && a.dataset.a === 'out') go('login.html', 'Đã đăng xuất thành công');
    if (a && a.dataset.a === 'info') {
      modal('Thông tin admin',
        `<div class="info-row"><span>Tên admin</span><b>Nguyễn Văn A</b></div>
         <div class="info-row"><span>Email</span><b>admin@gmail.com</b></div>
         <div class="info-row"><span>Số điện thoại</span><b>03636363636</b></div>`);
    }
  });
})();
